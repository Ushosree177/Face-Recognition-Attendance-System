#from ui.app import App
 
#if __name__ == "__main__":
 #  app.mainloop()
from ui.app import App

print("Starting App...")

if __name__ == "__main__":
    app = App()
    print("App created")
    app.mainloop()
    print("Mainloop ended")